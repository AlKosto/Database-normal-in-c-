﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Books_Information
{
    public partial class Show_info : Form
    {
        public Show_info()
        {
            InitializeComponent();
        }
        SqlConnection ABC = new SqlConnection(@"Data Source=KOSTO\SQLEXPRESS;Initial Catalog=Book_Detals;Integrated Security=True");
        SqlCommand command = new SqlCommand();
        
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }



        private void Search()
        {

        }
        private void Show_info_Load(object sender, EventArgs e)
        {
            command.Connection = ABC;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ABC.Open();
            
            String query = "select * from Book_Info";
            SqlDataAdapter da = new SqlDataAdapter(query,ABC);
            DataTable dt = new DataTable("Book_Info");
           // command.ExecuteNonQuery();
            
            
            
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            da.Update(dt);
            ABC.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            String search = txt_search.Text;
            ABC.Open();

            String query = "select * from Book_Info where Name='"+search+"'";
            SqlDataAdapter da = new SqlDataAdapter(query, ABC);
            DataTable dt = new DataTable("Book_Info");
            // command.ExecuteNonQuery();



            da.Fill(dt);
            dataGridView1.DataSource = dt;
            da.Update(dt);
            ABC.Close();
        }
    }
}
