﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Books_Information
{
    public partial class Register : Form
    {
        public Register()
        {
            command.Connection = ABC;
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        SqlConnection ABC = new SqlConnection(@"Data Source=KOSTO\SQLEXPRESS;Initial Catalog=Book_Detals;Integrated Security=True");
        SqlCommand command = new SqlCommand();

        private void btn_reg_Click(object sender, EventArgs e)
        {

            if (txt_name.Text != "" && txt_pass.Text != "" )
            {
                ABC.Open();
                String name = txt_name.Text;
                String pass = txt_pass.Text;
                
                command.CommandText = "insert into login_info values('" + name + "','" + pass + "')";
                command.ExecuteNonQuery();
                ABC.Close();
                MessageBox.Show(name+" Your Information saved");
                txt_name.Text = "";
                txt_pass.Text = string.Empty;
                
            }
            else
            {
                MessageBox.Show("Enter all information");
            }
        }
    }
}
