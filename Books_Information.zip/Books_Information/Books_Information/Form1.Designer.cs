﻿namespace Books_Information
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grp_box_Index = new System.Windows.Forms.GroupBox();
            this.lbl_Show_Book = new System.Windows.Forms.Label();
            this.lbl_Add_Book = new System.Windows.Forms.Label();
            this.grp_box_Index.SuspendLayout();
            this.SuspendLayout();
            // 
            // grp_box_Index
            // 
            this.grp_box_Index.BackColor = System.Drawing.Color.Cornsilk;
            this.grp_box_Index.Controls.Add(this.lbl_Show_Book);
            this.grp_box_Index.Controls.Add(this.lbl_Add_Book);
            this.grp_box_Index.Font = new System.Drawing.Font("Niagara Solid", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_box_Index.Location = new System.Drawing.Point(19, 39);
            this.grp_box_Index.Name = "grp_box_Index";
            this.grp_box_Index.Size = new System.Drawing.Size(386, 228);
            this.grp_box_Index.TabIndex = 1;
            this.grp_box_Index.TabStop = false;
            this.grp_box_Index.Text = "Index";
            // 
            // lbl_Show_Book
            // 
            this.lbl_Show_Book.AutoSize = true;
            this.lbl_Show_Book.Font = new System.Drawing.Font("Harlow Solid Italic", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Show_Book.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lbl_Show_Book.Location = new System.Drawing.Point(121, 124);
            this.lbl_Show_Book.Name = "lbl_Show_Book";
            this.lbl_Show_Book.Size = new System.Drawing.Size(145, 34);
            this.lbl_Show_Book.TabIndex = 1;
            this.lbl_Show_Book.Text = "Show Book";
            this.lbl_Show_Book.Click += new System.EventHandler(this.lbl_Show_Book_Click);
            // 
            // lbl_Add_Book
            // 
            this.lbl_Add_Book.AutoSize = true;
            this.lbl_Add_Book.Font = new System.Drawing.Font("Poor Richard", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Add_Book.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lbl_Add_Book.Location = new System.Drawing.Point(140, 70);
            this.lbl_Add_Book.Name = "lbl_Add_Book";
            this.lbl_Add_Book.Size = new System.Drawing.Size(126, 31);
            this.lbl_Add_Book.TabIndex = 0;
            this.lbl_Add_Book.Text = "Add Book";
            this.lbl_Add_Book.Click += new System.EventHandler(this.lbl_Add_Book_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkKhaki;
            this.ClientSize = new System.Drawing.Size(425, 288);
            this.Controls.Add(this.grp_box_Index);
            this.Name = "Form1";
            this.Text = "Index";
            this.grp_box_Index.ResumeLayout(false);
            this.grp_box_Index.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grp_box_Index;
        private System.Windows.Forms.Label lbl_Show_Book;
        private System.Windows.Forms.Label lbl_Add_Book;
    }
}

