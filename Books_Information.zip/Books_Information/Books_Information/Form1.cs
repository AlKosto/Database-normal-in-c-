﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Books_Information
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Login ob = new Login();
            ob.Show();
        }

        private void lbl_Show_Book_Click(object sender, EventArgs e)
        {
            Show_info ob = new Show_info();
            ob.Show();
            this.Hide();
        }

        private void lbl_Add_Book_Click(object sender, EventArgs e)
        {
            Add_Book ob = new Add_Book();
            ob.Show();
            this.Hide();
        }
    }
}
