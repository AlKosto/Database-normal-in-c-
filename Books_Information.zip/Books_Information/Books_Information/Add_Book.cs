﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Books_Information
{
    public partial class Add_Book : Form
    {
        public Add_Book()
        {

            InitializeComponent();
        }

        SqlConnection ABC = new SqlConnection(@"Data Source=KOSTO\SQLEXPRESS;Initial Catalog=Book_Detals;Integrated Security=True");
        SqlCommand command = new SqlCommand();


        private void button1_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }

        private void book_InfoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.book_InfoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.book_DetalsDataSet);

        }

        private void Add_Book_Load(object sender, EventArgs e)
        {
             command.Connection = ABC;
             this.book_InfoTableAdapter.Fill(this.book_DetalsDataSet.Book_Info);

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           
                if(txt_author.Text!="" && txt_isbn.Text!="" && txt_name.Text != "") {
                ABC.Open();
                String name = txt_name.Text;
                String isbn = txt_isbn.Text;
                String author = txt_author.Text;
                command.CommandText = "insert into Book_Info(Name, ISBN, Author) values('" + name+"','"+isbn+"','"+author+"')";
                command.ExecuteNonQuery();
                ABC.Close();
                MessageBox.Show("Information saved");
                txt_name.Text = "";
                txt_isbn.Text = string.Empty;
                txt_author.Text = "";
            }
            else
            {
                MessageBox.Show("Enter all information");
            }
            
          }

        
    }
}
