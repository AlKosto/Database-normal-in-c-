﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Books_Information
{
    public partial class Login : Form
    {
        SqlConnection ABC = new SqlConnection(@"Data Source=KOSTO\SQLEXPRESS;Initial Catalog=Book_Detals;Integrated Security=True");
        SqlCommand command = new SqlCommand();
        public Login()
        {
            command.Connection = ABC;
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            ABC.Open();

            String query = "select * from login_info where User_Name='"+txt_name.Text+"' and User_Password='"+txt_pass.Text+"'";
            SqlDataAdapter da = new SqlDataAdapter(query, ABC);
            DataTable dt = new DataTable("login_info");
            // command.ExecuteNonQuery();



            da.Fill(dt);
            if (dt.Rows[0][0] != "")
            {
                MessageBox.Show("ok");
                Form1 ob = new Form1();
                ob.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("You are not allow to login");
            }
            da.Update(dt);
            ABC.Close();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            Register ob = new Register();
            ob.Show();
            this.Hide();
        }
    }
}
